<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>QwikHome - {{ auth()->user()->role == 'admin' ? 'Admin' : 'Vendor' }} Panel</title>

    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.6.1/nouislider.min.css" rel="stylesheet">
    <!--====== Summernote CSS ======-->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <!--====== Jquery js ======-->
    <script src="{{ asset('website/assets/vendor/jquery-3.7.1.min.js') }}"></script>

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="{{ asset('website/assets/vendor/bootstrap/css/bootstrap.min.css') }}">
    <!--====== Bootstrap js ======-->
    <script src="{{ asset('website/assets/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
    <!--====== Bootstrap js ======-->
    <script src="{{ asset('website/assets/vendor/popper/popper.min.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="{{ asset('js/admin.js') }}"></script>
    <style>
        /* Modern Service Management Dropdown Styling */
        .service-dropdown-menu {
            display: none;
            background: rgba(45, 45, 45, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            min-width: 220px;
            z-index: 1000;
            margin-top: 8px;
            overflow: hidden;
        }

        /* Collapsed Sidebar Service Management Fixes */
        .sidebar.collapsed .service-menu {
            position: relative;
        }

        .sidebar.collapsed .service-menu-trigger {
            justify-content: center !important;
            padding: 12px 5px !important;
            min-height: 45px !important;
            display: flex !important;
            align-items: center !important;
            position: relative !important;
            width: 100% !important;
            max-width: 80px !important;
        }

        .sidebar.collapsed .service-menu-trigger span,
        .sidebar.collapsed .service-menu-trigger .fa-caret-down {
            display: none !important;
            opacity: 0 !important;
        }

        .sidebar.collapsed .service-menu-trigger i.fas.fa-cogs {
            margin-right: 0 !important;
            opacity: 1 !important;
            visibility: visible !important;
            font-size: 18px !important;
            color: rgba(255, 255, 255, 0.9) !important;
            width: 20px !important;
            height: 20px !important;
            text-align: center !important;
            display: inline-block !important;
            position: relative !important;
            z-index: 10 !important;
        }

        .sidebar.collapsed .service-dropdown-menu {
            display: none !important;
        }

        /* Hide flyout menu by default and only show in collapsed sidebar */
        .service-flyout-menu {
            display: none !important;
        }

        /* Collapsed sidebar flyout menu */
        .sidebar.collapsed .service-flyout-menu {
            display: block !important;
            position: absolute;
            left: 100%;
            top: 0;
            background: rgba(45, 45, 45, 0.95);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
            min-width: 220px;
            z-index: 1002;
            margin-left: 10px;
            overflow: hidden;
            opacity: 0;
            transform: translateX(-10px);
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .sidebar.collapsed .service-flyout-menu.show {
            opacity: 1;
            transform: translateX(0);
            pointer-events: all;
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #ffffff;
            text-decoration: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item:last-child {
            border-bottom: none;
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item:hover {
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
            transform: translateX(5px);
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item i {
            width: 16px;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item:hover i {
            color: #00d4ff;
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item.active {
            background: rgba(0, 212, 255, 0.15);
            color: #00d4ff;
            border-left: 3px solid #00d4ff;
        }

        .sidebar.collapsed .service-flyout-menu .flyout-item.active i {
            color: #00d4ff;
        }

        .sidebar.collapsed .service-menu:hover .service-menu-trigger {
            background: rgba(0, 212, 255, 0.1) !important;
            border-left: 3px solid #00d4ff !important;
        }

        .sidebar.collapsed .service-menu:hover .service-menu-trigger i.fas.fa-cogs {
            color: #00d4ff !important;
        }

        /* Tooltip for collapsed service menu - hide when flyout is open */
        .sidebar.collapsed .service-menu-trigger:hover::after {
            content: "Service Management";
            position: absolute;
            left: 100%;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.9);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            white-space: nowrap;
            z-index: 1001;
            margin-left: 10px;
            opacity: 0;
            animation: fadeInTooltip 0.3s ease forwards;
        }

        .sidebar.collapsed .service-menu .service-flyout-menu.show~.service-menu-trigger:hover::after {
            display: none;
        }

        @keyframes fadeInTooltip {
            to {
                opacity: 1;
            }
        }

        /* Additional fixes for service menu in collapsed state */
        .sidebar.collapsed .nav-item .service-menu {
            width: 100%;
            display: block;
        }

        .sidebar.collapsed .nav-item .service-menu .service-menu-trigger {
            border-left: 3px solid transparent;
            transition: all 0.3s ease;
        }

        .sidebar.collapsed .nav-item.active .service-menu-trigger {
            background: rgba(0, 212, 255, 0.1);
            border-left-color: #00d4ff;
        }

        .sidebar.collapsed .nav-item.active .service-menu-trigger i.fas.fa-cogs {
            color: #00d4ff;
        }

        .service-dropdown-menu .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #ffffff;
            text-decoration: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .service-dropdown-menu .dropdown-item:hover,
        .service-dropdown-menu .dropdown-item.active {
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
            transform: translateX(4px);
        }

        .service-dropdown-menu .dropdown-item i {
            width: 18px;
            text-align: center;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        .service-dropdown-menu .dropdown-item:hover i,
        .service-dropdown-menu .dropdown-item.active i {
            color: #00d4ff;
            transform: scale(1.1);
        }

        .service-dropdown-menu .dropdown-item:last-child {
            border-bottom: none;
        }

        .service-dropdown-menu .dropdown-item span {
            transition: all 0.3s ease;
        }

        /* Enhanced arrow animation */
        .fa-caret-down.rotate {
            transform: rotate(180deg);
            transition: transform 0.3s ease;
            color: #00d4ff;
        }

        .fa-caret-down {
            transition: all 0.3s ease;
            color: rgba(255, 255, 255, 0.7);
        }

        /* Service menu trigger hover effect */
        .service-menu-trigger:hover .fa-caret-down {
            color: #00d4ff;
        }

        /* Add subtle glow effect */
        .service-dropdown-menu::before {
            content: '';
            position: absolute;
            top: -1px;
            left: -1px;
            right: -1px;
            bottom: -1px;
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(0, 153, 204, 0.2));
            border-radius: 12px;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .service-dropdown-menu:hover::before {
            opacity: 1;
        }

        /* Smooth slide animation */
        .service-dropdown-menu {
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Mobile responsive adjustments */
        @media (max-width: 768px) {
            .service-dropdown-menu {
                min-width: 200px;
                margin-top: 4px;
            }

            .service-dropdown-menu .dropdown-item {
                padding: 10px 14px;
                font-size: 13px;
            }

            .service-dropdown-menu .dropdown-item i {
                width: 16px;
                font-size: 13px;
            }
        }

        /* Enhanced active state for service management */
        .nav-item.active .service-menu-trigger {
            color: #ffffff !important;
            background: rgba(0, 212, 255, 0.1) !important;
        }

        .nav-item.active .service-menu-trigger i {
            color: #00d4ff !important;
        }

        /* Ensure parent nav-item gets active styling */
        .nav-item.active {
            border-left: 3px solid #00d4ff;
        }

        /* Specific styling for Employees nav item */
        .nav-item.nav-employees.active {
            border-left: 3px solid #10b981 !important;
            background: rgba(16, 185, 129, 0.1) !important;
        }

        .nav-item.nav-employees.active .nav-link {
            color: #ffffff !important;
        }

        .nav-item.nav-employees.active .nav-link i {
            color: #10b981 !important;
        }

        /* Specific styling for Bookings nav item */
        .nav-item.nav-bookings.active {
            border-left: 3px solid #3b82f6 !important;
            background: rgba(59, 130, 246, 0.1) !important;
        }

        .nav-item.nav-bookings.active .nav-link {
            color: #ffffff !important;
        }

        .nav-item.nav-bookings.active .nav-link i {
            color: #3b82f6 !important;
        }

        /* Protection against Service Management JS interference */
        .nav-item.nav-employees,
        .nav-item.nav-bookings {
            position: relative;
            z-index: 10;
        }

        /* Content Management Dropdown Styling */
        .content-dropdown-menu {
            display: none;
            background: rgba(45, 45, 45, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            min-width: 220px;
            z-index: 1000;
            margin-top: 8px;
            overflow: hidden;
            animation: slideDown 0.3s ease-out;
        }

        /* Similar styling for content dropdown as service dropdown */
        .content-menu {
            position: relative;
        }

        .content-menu-trigger {
            padding: 12px 15px;
            color: #ffffff;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .content-menu-trigger:hover {
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
        }

        .content-menu-trigger i.fas.fa-edit {
            font-size: 16px;
            color: rgba(255, 255, 255, 0.8);
            transition: all 0.3s ease;
            margin-right: 12px;
        }

        .content-menu-trigger:hover i.fas.fa-edit {
            color: #00d4ff;
        }

        .content-menu-trigger span {
            flex-grow: 1;
            font-size: 14px;
            font-weight: 500;
        }

        .content-dropdown-menu .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #ffffff;
            text-decoration: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .content-dropdown-menu .dropdown-item:hover,
        .content-dropdown-menu .dropdown-item.active {
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
            transform: translateX(4px);
        }

        .content-dropdown-menu .dropdown-item i {
            width: 18px;
            text-align: center;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        .content-dropdown-menu .dropdown-item:hover i,
        .content-dropdown-menu .dropdown-item.active i {
            color: #00d4ff;
            transform: scale(1.1);
        }

        .content-dropdown-menu .dropdown-item:last-child {
            border-bottom: none;
        }

        .content-dropdown-menu .dropdown-item span {
            transition: all 0.3s ease;
        }

        /* Collapsed Sidebar Content Management */
        .sidebar.collapsed .content-menu-trigger {
            justify-content: center !important;
            padding: 12px 5px !important;
            min-height: 45px !important;
            display: flex !important;
            align-items: center !important;
            position: relative !important;
            width: 100% !important;
            max-width: 80px !important;
        }

        .sidebar.collapsed .content-menu-trigger span,
        .sidebar.collapsed .content-menu-trigger .fa-caret-down {
            display: none !important;
            opacity: 0 !important;
        }

        .sidebar.collapsed .content-menu-trigger i.fas.fa-edit {
            margin-right: 0 !important;
            font-size: 18px !important;
            color: rgba(255, 255, 255, 0.9) !important;
            width: 20px !important;
            height: 20px !important;
            text-align: center !important;
            display: inline-block !important;
            position: relative !important;
            z-index: 10 !important;
        }

        .sidebar.collapsed .content-dropdown-menu {
            display: none !important;
        }

        /* Content Management Flyout Menu for Collapsed Sidebar */
        .sidebar.collapsed .content-flyout-menu {
            display: block !important;
            position: absolute;
            left: 100%;
            top: 0;
            background: rgba(45, 45, 45, 0.95);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
            min-width: 200px;
            z-index: 1002;
            margin-left: 10px;
            overflow: hidden;
            opacity: 0;
            transform: translateX(-10px);
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .sidebar.collapsed .content-flyout-menu.show {
            opacity: 1;
            transform: translateX(0);
            pointer-events: all;
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #ffffff;
            text-decoration: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item:last-child {
            border-bottom: none;
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item:hover {
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
            transform: translateX(5px);
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item i {
            width: 16px;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item:hover i {
            color: #00d4ff;
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item.active {
            background: rgba(0, 212, 255, 0.15);
            color: #00d4ff;
            border-left: 3px solid #00d4ff;
        }

        .sidebar.collapsed .content-flyout-menu .flyout-item.active i {
            color: #00d4ff;
        }

        /* Tooltip for collapsed content menu */
        .sidebar.collapsed .content-menu-trigger:hover::after {
            content: "Content Management";
            position: absolute;
            left: 100%;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.9);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            white-space: nowrap;
            z-index: 1001;
            margin-left: 10px;
            opacity: 0;
            animation: fadeInTooltip 0.3s ease forwards;
        }

        .sidebar.collapsed .content-menu .content-flyout-menu.show~.content-menu-trigger:hover::after {
            display: none;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="{{ asset('images/qwikhom_logo.png') }}" alt="QwikHome" class="logo-image">
            </div>
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <nav class="sidebar-nav">
            <ul>
                @if (auth()->user()->role == 'admin' || auth()->user()->role == 'vendor')
                    <li class="nav-item {{ request()->is('admin') ? 'active' : '' }} ">
                        <a href="{{ route('admin.dashboard') }}" class="nav-link" data-section="dashboard">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                @endif
                @if (auth()->user()->role == 'admin')
                    <li class="nav-item {{ request()->is('customers*') ? 'active' : '' }} ">
                        <a href="{{ route('customers') }}" class="nav-link">
                            <i class="fas fa-users"></i>
                            <span>Customer Management</span>
                        </a>
                    </li>
                @endif

                <li
                    class="nav-item {{ str_contains(request()->url(), '/services') ||
                    str_contains(request()->url(), '/categories') ||
                    str_contains(request()->url(), '/subcategories')
                        ? 'active'
                        : '' }}">
                    <div class="service-menu">
                        <a href="javascript:void(0)" class="nav-link service-menu-trigger">
                            <i class="fas fa-cogs"></i>
                            <span>Service Management</span>
                            <i class="fas fa-caret-down ml-1"></i>
                        </a>
                        <div class="service-dropdown-menu" style="display: none;">
                            <a href="{{ route('services.categories.index') }}"
                                class="dropdown-item {{ request()->routeIs('services.categories.*') ? 'active' : '' }}">
                                <i class="fas fa-folder"></i>
                                <span>Categories</span>
                            </a>

                            <a href="{{ route('services.subcategories.index') }}"
                                class="dropdown-item {{ request()->routeIs('services.subcategories.*') ? 'active' : '' }}">
                                <i class="fas fa-folder-open"></i>
                                <span>Sub-Category</span>
                            </a>
                            <a href="{{ route('services.services.index') }}"
                                class="dropdown-item {{ request()->routeIs('services.services.*') ? 'active' : '' }}">
                                <i class="fas fa-concierge-bell"></i>
                                <span>Services</span>
                            </a>
                        </div>
                        <!-- Flyout menu for collapsed sidebar -->
                        <div class="service-flyout-menu">
                            <a href="{{ route('services.categories.index') }}"
                                class="flyout-item {{ request()->routeIs('services.categories.*') ? 'active' : '' }}">
                                <i class="fas fa-folder"></i>
                                <span>Categories</span>
                            </a>
                            <a href="{{ route('services.subcategories.index') }}"
                                class="flyout-item {{ request()->routeIs('services.subcategories.*') ? 'active' : '' }}">
                                <i class="fas fa-folder-open"></i>
                                <span>Sub-Category</span>
                            </a>
                            <a href="{{ route('services.services.index') }}"
                                class="flyout-item {{ request()->routeIs('services.services.*') ? 'active' : '' }}">
                                <i class="fas fa-concierge-bell"></i>
                                <span>Services</span>
                            </a>
                        </div>
                    </div>
                </li>



                <script>
                    $(document).ready(function() {
                        function isServiceManagementPage() {
                            const path = window.location.pathname;
                            const href = window.location.href;
                            return path.includes('/services') ||
                                path.includes('/categories') ||
                                path.includes('/subcategories') ||
                                href.includes('services.categories') ||
                                href.includes('services.subcategories') ||
                                href.includes('services.services');
                        }

                        // Check if on service management page and show dropdown
                        if (isServiceManagementPage()) {
                            $(".service-dropdown-menu").show();
                            $(".service-menu-trigger").find(".fa-caret-down").addClass("rotate");

                            // Highlight active section based on current route
                            const currentPath = window.location.pathname;
                            const currentRoute = window.location.href;

                            // Check for services routes (more specific patterns)
                            if (currentPath.includes('/services') &&
                                (currentRoute.includes('services.services') ||
                                    (!currentPath.includes('/categories') && !currentPath.includes('/subcategories')))) {
                                $('.service-dropdown-menu a[href*="services.services"]').addClass('active');
                            }
                            // Check for categories routes
                            else if (currentPath.includes('/categories') || currentRoute.includes('services.categories')) {
                                $('.service-dropdown-menu a[href*="services.categories"]').addClass('active');
                            }
                            // Check for subcategories routes
                            else if (currentPath.includes('/subcategories') || currentRoute.includes(
                                    'services.subcategories')) {
                                $('.service-dropdown-menu a[href*="services.subcategories"]').addClass('active');
                            }
                        }

                        $(".service-menu-trigger").on("click", function(e) {
                            e.preventDefault();

                            // Handle collapsed sidebar - show flyout menu
                            if ($('.sidebar').hasClass('collapsed')) {
                                const $flyout = $(this).siblings(".service-flyout-menu");

                                // Close any other open flyouts first
                                $('.service-flyout-menu').not($flyout).removeClass('show');

                                // Toggle current flyout
                                $flyout.toggleClass('show');

                                return false;
                            }

                            const $dropdown = $(this).next(".service-dropdown-menu");
                            const $arrow = $(this).find(".fa-caret-down");

                            $dropdown.slideToggle(200);
                            $arrow.toggleClass("rotate");
                        });

                        // Handle sidebar collapse behavior for service menu
                        function handleServiceMenuCollapse() {
                            if ($('.sidebar').hasClass('collapsed')) {
                                // Hide dropdown and reset arrow when collapsed
                                $('.service-dropdown-menu').hide();
                                $('.service-menu-trigger .fa-caret-down').removeClass('rotate');
                                // Also hide any open flyout menus
                                $('.service-flyout-menu').removeClass('show');
                            } else {
                                // Show dropdown if on service management page when expanded
                                if (isServiceManagementPage()) {
                                    $('.service-dropdown-menu').show();
                                    $('.service-menu-trigger .fa-caret-down').addClass('rotate');
                                }
                                // Hide flyout menu when expanded
                                $('.service-flyout-menu').removeClass('show');
                            }
                        }

                        // Handle flyout menu active states
                        function updateFlyoutActiveStates() {
                            const currentPath = window.location.pathname;
                            const currentRoute = window.location.href;

                            // Remove all active classes first
                            $('.service-flyout-menu .flyout-item').removeClass('active');

                            // Add active class based on current route
                            if (currentPath.includes('/services') &&
                                (currentRoute.includes('services.services') ||
                                    (!currentPath.includes('/categories') && !currentPath.includes('/subcategories')))) {
                                $('.service-flyout-menu a[href*="services.services"]').addClass('active');
                            } else if (currentPath.includes('/categories') || currentRoute.includes('services.categories')) {
                                $('.service-flyout-menu a[href*="services.categories"]').addClass('active');
                            } else if (currentPath.includes('/subcategories') || currentRoute.includes(
                                    'services.subcategories')) {
                                $('.service-flyout-menu a[href*="services.subcategories"]').addClass('active');
                            }
                        }

                        // Initialize flyout active states
                        updateFlyoutActiveStates();

                        // Close flyout menu when clicking outside
                        $(document).on('click', function(e) {
                            if (!$(e.target).closest('.service-menu').length) {
                                $('.service-flyout-menu').removeClass('show');
                            }
                        });

                        // Prevent flyout from closing when clicking inside it
                        $(document).on('click', '.service-flyout-menu', function(e) {
                            e.stopPropagation();
                        });

                        // Watch for sidebar collapse changes - only for service menu
                        const observer = new MutationObserver(function(mutations) {
                            mutations.forEach(function(mutation) {
                                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                                    const target = mutation.target;
                                    if (target.classList.contains('sidebar')) {
                                        handleServiceMenuCollapse();
                                    }
                                }
                            });
                        });

                        // Start observing sidebar for class changes - be more specific
                        const sidebar = document.querySelector('.sidebar');
                        if (sidebar) {
                            observer.observe(sidebar, {
                                attributes: true,
                                attributeFilter: ['class']
                            });
                        }

                        // Ensure other nav items are not affected by service menu JS
                        $(document).ready(function() {
                            // Store original active states before any JS manipulation
                            $('.nav-item').each(function() {
                                const $navItem = $(this);
                                if ($navItem.hasClass('active')) {
                                    $navItem.attr('data-original-active', 'true');
                                }
                            });

                            // Re-apply active states after service menu JS runs
                            setTimeout(function() {
                                $('.nav-item[data-original-active="true"]').each(function() {
                                    const $navItem = $(this);
                                    // Ensure active state is maintained and not overridden
                                    $navItem.addClass('active');
                                });
                            }, 200);
                        });

                        // Specific protection for Employees and Bookings nav items
                        $(document).on('click',
                            '.nav-employees a, .nav-bookings a, a[href*="serviceProviders"], a[href*="vendor/bookings"]',
                            function(e) {
                                const $navItem = $(this).closest('.nav-item');
                                // Ensure active state is applied immediately and protected
                                setTimeout(function() {
                                    $('.nav-item').removeClass('active');
                                    $navItem.addClass('active');
                                }, 10);
                            });

                        // Protect against Service Management JS interference
                        $(document).on('DOMSubtreeModified', '.nav-employees, .nav-bookings', function() {
                            const $navItem = $(this);
                            if ($navItem.attr('data-original-active') === 'true' && !$navItem.hasClass('active')) {
                                $navItem.addClass('active');
                            }
                        });
                    });

                    // Initialize user menu dropdown
                    $(document).on("click", ".user-trigger", function(e) {
                        e.stopPropagation();
                        $(this).closest(".user-menu").toggleClass("active");
                    });

                    // Close user menu when clicking outside
                    $(document).on("click", function(e) {
                        if (!$(e.target).closest(".user-menu").length) {
                            $(".user-menu").removeClass("active");
                        }
                    });

                    // Handle logout
                    $(document).on("click", ".user-menu .dropdown-item[href='#logout']", function(e) {
                        e.preventDefault();
                        $("#logout-form").submit();
                    });

                    // Mobile menu toggle
                    $(document).on("click", "#mobileMenuToggle", function(e) {
                        if ($(window).width() <= 768) {
                            $("#sidebar").toggleClass("open");
                        }
                    });

                    // Close mobile sidebar when clicking outside, on sidebar content, or hamburger again
                    $(document).on("click", "#mobileMenuToggle, #sidebar a", function(e) {
                        if ($(window).width() <= 768) {
                            // For sidebar links, close immediately
                            if ($(e.target).closest("#sidebar a").length) {
                                $("#sidebar").removeClass("open");
                            }
                        }
                    });

                    // Close mobile sidebar when clicking outside
                    $(document).on("click", function(e) {
                        if ($(window).width() <= 768) {
                            if (!$(e.target).closest("#sidebar, #mobileMenuToggle").length) {
                                $("#sidebar").removeClass("open");
                            }
                        }
                    });

                    // Swipe gesture for mobile sidebar
                    if ($(window).width() <= 768) {
                        let touchStartX = 0;
                        let touchStartY = 0;
                        let touchEndX = 0;
                        let touchEndY = 0;

                        $("#sidebar").on("touchstart", function(e) {
                            touchStartX = e.originalEvent.touches[0].clientX;
                            touchStartY = e.originalEvent.touches[0].clientY;
                        });

                        $("#sidebar").on("touchmove", function(e) {
                            if (!touchStartX || !touchStartY) return;

                            touchEndX = e.originalEvent.touches[0].clientX;
                            touchEndY = e.originalEvent.touches[0].clientY;

                            const deltaX = touchStartX - touchEndX;
                            const deltaY = Math.abs(touchStartY - touchEndY);

                            // If horizontal swipe is greater than vertical, handle it
                            if (Math.abs(deltaX) > deltaY && Math.abs(deltaX) > 50) {
                                if (deltaX > 50) { // Left swipe
                                    e.preventDefault();
                                    $("#sidebar").removeClass("open");
                                }
                            }
                        });

                        $("#sidebar").on("touchend", function() {
                            touchStartX = 0;
                            touchStartY = 0;
                            touchEndX = 0;
                            touchEndY = 0;
                        });
                    }

                    // Sidebar toggle (desktop)
                    $(document).on("click", "#sidebarToggle", function(e) {
                        $("#sidebar").removeClass("open").toggleClass("collapsed");
                        $(".main-content").toggleClass("collapsed");
                    });
                </script>

                <!-- Content Management Menu JavaScript -->
                <script>
                    $(document).ready(function() {
                        function isContentManagementPage() {
                            const path = window.location.pathname;
                            return path.includes('/content-management') ||
                                path.includes('admin.contentManagement');
                        }

                        // Check if on content management page and show dropdown
                        if (isContentManagementPage()) {
                            $(".content-dropdown-menu").show();
                            $(".content-menu-trigger").find(".fa-caret-down").addClass("rotate");

                            // Highlight active section based on current route
                            const currentPath = window.location.pathname;
                            const currentRoute = window.location.href;

                            // Check for banners routes
                            if (currentPath.includes('/banners') || currentRoute.includes('contentManagement.banners')) {
                                $('.content-dropdown-menu a[href*="contentManagement.banners"]').addClass('active');
                            }
                            // Check for offers routes
                            else if (currentPath.includes('/offers') || currentRoute.includes('contentManagement.offers')) {
                                $('.content-dropdown-menu a[href*="contentManagement.offers"]').addClass('active');
                            }
                            // Check for campaigns routes
                            else if (currentPath.includes('/campaigns') || currentRoute.includes(
                                    'contentManagement.campaigns')) {
                                $('.content-dropdown-menu a[href*="contentManagement.campaigns"]').addClass('active');
                            }
                        }

                        $(".content-menu-trigger").on("click", function(e) {
                            e.preventDefault();

                            // Handle collapsed sidebar - show flyout menu
                            if ($('.sidebar').hasClass('collapsed')) {
                                const $flyout = $(this).parent().find(".content-flyout-menu");

                                // Close any other open flyouts first
                                $('.content-flyout-menu').not($flyout).removeClass('show');
                                $('.service-flyout-menu').removeClass('show'); // Close service flyout too

                                // Toggle current flyout
                                $flyout.toggleClass('show');

                                return false;
                            }

                            const $dropdown = $(this).next(".content-dropdown-menu");
                            const $arrow = $(this).find(".fa-caret-down");

                            // Close other dropdowns first
                            $('.service-dropdown-menu').hide();
                            $('.service-menu-trigger .fa-caret-down').removeClass('rotate');

                            $dropdown.slideToggle(200);
                            $arrow.toggleClass("rotate");
                        });

                        // Handle sidebar collapse behavior for content menu
                        function handleContentMenuCollapse() {
                            if ($('.sidebar').hasClass('collapsed')) {
                                // Hide dropdown and reset arrow when collapsed
                                $('.content-dropdown-menu').hide();
                                $('.content-menu-trigger .fa-caret-down').removeClass('rotate');
                                // Also hide any open flyout menus
                                $('.content-flyout-menu').removeClass('show');
                            } else {
                                // Show dropdown if on content management page when expanded
                                if (isContentManagementPage()) {
                                    $('.content-dropdown-menu').show();
                                    $('.content-menu-trigger .fa-caret-down').addClass('rotate');
                                }
                                // Hide flyout menu when expanded
                                $('.content-flyout-menu').removeClass('show');
                            }
                        }

                        // Handle flyout menu active states
                        function updateContentFlyoutActiveStates() {
                            const currentPath = window.location.pathname;
                            const currentRoute = window.location.href;

                            // Remove all active classes first
                            $('.content-flyout-menu .flyout-item').removeClass('active');

                            // Add active class based on current route
                            if (currentPath.includes('/banners') || currentRoute.includes('contentManagement.banners')) {
                                $('.content-flyout-menu a[href*="contentManagement.banners"]').addClass('active');
                            } else if (currentPath.includes('/offers') || currentRoute.includes('contentManagement.offers')) {
                                $('.content-flyout-menu a[href*="contentManagement.offers"]').addClass('active');
                            } else if (currentPath.includes('/campaigns') || currentRoute.includes(
                                    'contentManagement.campaigns')) {
                                $('.content-flyout-menu a[href*="contentManagement.campaigns"]').addClass('active');
                            }
                        }

                        // Initialize flyout active states
                        updateContentFlyoutActiveStates();

                        // Close flyout menu when clicking outside
                        $(document).on('click', function(e) {
                            if (!$(e.target).closest('.content-menu').length) {
                                $('.content-flyout-menu').removeClass('show');
                            }
                        });

                        // Prevent flyout from closing when clicking inside it
                        $(document).on('click', '.content-flyout-menu', function(e) {
                            e.stopPropagation();
                        });

                        // Watch for sidebar collapse changes - only for content menu
                        const observer = new MutationObserver(function(mutations) {
                            mutations.forEach(function(mutation) {
                                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                                    const target = mutation.target;
                                    if (target.classList.contains('sidebar')) {
                                        handleContentMenuCollapse();
                                        // Also handle service menu collapse
                                        // (existing service menu collapse function call would go here)
                                    }
                                }
                            });
                        });

                        // Start observing sidebar for class changes
                        const sidebar = document.querySelector('.sidebar');
                        if (sidebar) {
                            observer.observe(sidebar, {
                                attributes: true,
                                attributeFilter: ['class']
                            });
                        }

                        // Handle content menu active states
                        $(document).ready(function() {
                            // Store original active states before any JS manipulation
                            $('.nav-item').each(function() {
                                const $navItem = $(this);
                                if ($navItem.hasClass('active')) {
                                    $navItem.attr('data-original-active', 'true');
                                }
                            });

                            // Re-apply active states after content menu JS runs
                            setTimeout(function() {
                                $('.nav-item[data-original-active="true"]').each(function() {
                                    const $navItem = $(this);
                                    // Ensure active state is maintained and not overridden
                                    $navItem.addClass('active');
                                });
                            }, 200);
                        });
                    });
                </script>

                @if (auth()->user()->role == 'admin')
                    <li class="nav-item {{ request()->is('vendor/bookings*') ? 'active' : '' }}">
                        <a href="{{ route('vendor.bookings.index') }}" class="nav-link">
                            <i class="fas fa-tasks"></i>
                            <span>Bookings Monitoring</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->is('vendors*') ? 'active' : '' }}">
                        <a href="{{ route('admin.vendors.index') }}" class="nav-link">
                            <i class="fas fa-user-tie"></i>
                            <span>Vendor Management</span>
                        </a>
                    </li>

                    <li class="nav-item {{ request()->is('serviceProviders*') ? 'active' : '' }}">
                        <a href="{{ route('serviceProviders.index') }}" class="nav-link">
                            <i class="fas fa-user-plus"></i>
                            <span>Employees</span>
                        </a>
                    </li>

                    <li class="nav-item {{ request()->is('coupons*') ? 'active' : '' }}">
                        <a href="{{ route('coupons.index') }}" class="nav-link">
                            <i class="fas fa-tags"></i>
                            <span>Coupons</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->is('promocodes*') ? 'active' : '' }}">
                        <a href="{{ route('promocodes.index') }}" class="nav-link">
                            <i class="fas fa-gift"></i>
                            <span>Promo Codes</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-bell"></i>
                            <span>Push Notifications</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->is('analytics') ? 'active' : '' }}">
                        <a href="{{ route('admin.analytics.index') }}" class="nav-link">
                            <i class="fas fa-chart-bar"></i>
                            <span>Reports & Analytics</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->is('complaints*') ? 'active' : '' }}">
                        <a href="{{ route('complaints.index') }}" class="nav-link">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span>Complaints</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->is('feedback*') ? 'active' : '' }}">
                        <a href="{{ route('feedback.index') }}" class="nav-link">
                            <i class="fas fa-comments"></i>
                            <span>Feedbacks</span>
                        </a>
                    </li>
                    <li class="nav-item {{ str_contains(request()->url(), '/content-management') ? 'active' : '' }}">
                        <div class="content-menu">
                            <a href="javascript:void(0)" class="nav-link content-menu-trigger">
                                <i class="fas fa-edit"></i>
                                <span>Content Management</span>
                                <i class="fas fa-caret-down ml-1"></i>
                            </a>
                            <div class="content-dropdown-menu" style="display: none;">
                                <a href="{{ route('contentManagement.banners.index') }}"
                                    class="dropdown-item {{ request()->routeIs('admin.contentManagement.banners.*') ? 'active' : '' }}">
                                    <i class="fas fa-images"></i>
                                    <span>Banners</span>
                                </a>

                                <a href="{{ route('contentManagement.offers.index') }}"
                                    class="dropdown-item {{ request()->routeIs('admin.contentManagement.offers.*') ? 'active' : '' }}">
                                    <i class="fas fa-percent"></i>
                                    <span>Offers</span>
                                </a>
                                <a href="{{ route('contentManagement.campaigns.index') }}"
                                    class="dropdown-item {{ request()->routeIs('admin.contentManagement.campaigns.*') ? 'active' : '' }}">
                                    <i class="fas fa-bullhorn"></i>
                                    <span>Campaigns</span>
                                </a>
                            </div>

                        </div>
                    </li>
                    {{-- <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-user-plus"></i>
                            <span>Lead Management</span>
                        </a>
                    </li> --}}
                    <li class="nav-item {{ request()->is('faqs*') ? 'active' : '' }}">
                        <a href="{{ route('faq') }}" class="nav-link">
                            <i class="fas fa-question-circle"></i>
                            <span>FAQ's</span>
                        </a>
                    </li>
                @else
                    <li class="nav-item {{ request()->is('serviceProviders*') ? 'active' : '' }}">
                        <a href="{{ route('serviceProviders.index') }}" class="nav-link">
                            <i class="fas fa-user-plus"></i>
                            <span>Service Providers</span>
                        </a>
                    </li>

                    <li class="nav-item {{ request()->is('profile*') ? 'active' : '' }}">
                        <a href="{{ route('profile.show') }}" class="nav-link">
                            <i class="fas fa-user"></i>
                            <span>My Profile</span>
                        </a>
                    </li>
                @endif
            </ul>
        </nav>

        {{-- <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="user-details">
                    <span class="user-name">Admin User</span>
                    <span class="user-role">Super Admin</span>
                </div>
            </div>
            <button class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
            </button>
        </div> --}}
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <i class="fas fa-bars"></i>
                </button>

                <h1 class="page-title">{{ auth()->user()->role == 'admin' ? 'Admin' : 'Vendor' }} Dashboard</h1>
            </div>
            <div class="header-right">

                <div class="header-actions">
                    <button class="notification-btn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </button>
                    <div class="user-menu">
                        <span class="user-trigger">{{ auth()->user()->name }}
                            <a href="#logout" class="dropdown-item">Logout</a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                style="display: none;">
                                @csrf
                            </form>
                        </span>

                        {{-- <div class="dropdown-menu">
                        <a href="#profile" class="dropdown-item">Profile</a>
                        <a href="#settings" class="dropdown-item">Settings</a>

                    </div> --}}
                    </div>
                </div>
            </div>
        </header>
