@extends('layouts.app')

@section('title', 'Refund Policy | QwikHom')

@section('styles')
<style>
body { background-color: black !important; color: white !important; }
.card { background-color: #333 !important; border-color: #666 !important; }
.card-title, .card-text { color: white !important; }
.card-text li { color: white !important; }
</style>
@endsection

@section('content')
<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mb-4">Refund Policy</h1>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Service Cancellation and Refunds</h5>
                    <p class="card-text">
                        At QwikHom, we strive to provide excellent service. If you're not satisfied with our platform, please review our refund policy below.
                    </p>

                    <h5 class="card-title mt-4">Cancellation Policy</h5>
                    <ul class="card-text">
                        <li><strong>Before Service Confirmation:</strong> You can cancel your booking at any time before the service provider confirms the booking, and you will receive a full refund.</li>
                        <li><strong>After Service Confirmation:</strong> Cancellations made within 24 hours of the confirmed service time will receive a 50% refund.</li>
                        <li><strong>Less than 2 hours before service:</strong> No refund will be provided if cancellation occurs less than 2 hours before the scheduled service time.</li>
                    </ul>

                    <h5 class="card-title mt-4">Service Quality Issues</h5>
                    <p class="card-text">
                        If you are not satisfied with the service quality provided by our partnered service professionals, please contact our support team within 24 hours of service completion. We will:
                    </p>
                    <ul class="card-text">
                        <li>Investigate the complaint</li>
                        <li>Attempt to resolve the issue by re-scheduling the service or providing alternative arrangements</li>
                        <li>Process refunds or partial refunds based on the severity of the issue</li>
                    </ul>

                    <h5 class="card-title mt-4">Refund Processing</h5>
                    <p class="card-text">
                        Refunds are processed within 5-7 business days after the refund request is approved. Refunds will be issued to the original payment method used for the transaction.
                    </p>

                    <h5 class="card-title mt-4">Non-Refundable Items</h5>
                    <ul class="card-text">
                        <li>Convenience fees for emergency services</li>
                        <li>Third-party service charges (if applicable)</li>
                        <li>Transportation fees for service providers</li>
                        <li>Material costs (when already purchased for the service)</li>
                    </ul>

                    <h5 class="card-title mt-4">No-Show Policy</h5>
                    <p class="card-text">
                        If you fail to be present for a confirmed service booking without prior cancellation, no refund will be provided. However, we may offer a one-time courtesy rescheduling based on availability.
                    </p>

                    <h5 class="card-title mt-4">Contact Us</h5>
                    <p class="card-text">
                        For refund requests or questions about our refund policy, please contact our support team at refunds@qwikhom.com or call our helpline.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
