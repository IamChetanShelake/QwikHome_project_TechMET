@extends('layouts.app')

@section('title', 'Privacy Policy | QwikHom')

@section('styles')
<style>
body { background-color: black !important; color: white !important; }
.card { background-color: #333 !important; border-color: #666 !important; }
.card-title, .card-text { color: white !important; }
.card-text li { color: white !important; }
</style>
@endsection

@section('content')
<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mb-4">Privacy Policy</h1>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Information We Collect</h5>
                    <p class="card-text">
                        We collect information you provide directly to us. For example, we collect information when you use our services, complete a registration form, contact us, or otherwise communicate with us. The types of information we may collect include your name, email address, phone number, and any other information you choose to provide.
                    </p>

                    <h5 class="card-title mt-4">How We Use Your Information</h5>
                    <p class="card-text">
                        We may use the information we collect from you to:
                    </p>
                    <ul class="card-text">
                        <li>Provide, maintain, and improve our services</li>
                        <li>Process transactions and send related information</li>
                        <li>Send you technical notices, updates, security alerts, and support messages</li>
                        <li>Communicate with you about products, services, offers, promotions, and events</li>
                        <li>Monitor and analyze trends, usage, and activities</li>
                    </ul>

                    <h5 class="card-title mt-4">Information Sharing</h5>
                    <p class="card-text">
                        We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this policy. We may share your information in the following circumstances:
                    </p>
                    <ul class="card-text">
                        <li>With service providers who assist us in operating our website</li>
                        <li>When required by law or to protect our rights</li>
                        <li>In connection with a merger, acquisition, or sale of our company</li>
                    </ul>

                    <h5 class="card-title mt-4">Data Security</h5>
                    <p class="card-text">
                        We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no internet transmission is completely secure, and we cannot guarantee absolute security.
                    </p>

                    <h5 class="card-title mt-4">Cookies</h5>
                    <p class="card-text">
                        We use cookies and similar technologies to enhance your experience on our website. You can control cookie settings through your browser preferences.
                    </p>

                    <h5 class="card-title mt-4">Contact Us</h5>
                    <p class="card-text">
                        If you have any questions about this Privacy Policy, please contact us at privacy@qwikhom.com.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
