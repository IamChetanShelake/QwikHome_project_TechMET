@extends('layouts.app')

@section('title', 'Disclaimer | QwikHom')

@section('styles')
<style>
body { background-color: black !important; color: white !important; }
.card { background-color: #333 !important; border-color: #666 !important; }
.card-title, .card-text { color: white !important; }
</style>
@endsection

@section('content')
<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mb-4">Disclaimer</h1>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Website Disclaimer</h5>
                    <p class="card-text">
                        The information contained in this website is for general information purposes only. The information is provided by QwikHom and while we endeavour to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose.
                    </p>
                    <p class="card-text">
                        Any reliance you place on such information is therefore strictly at your own risk. In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.
                    </p>
                    <p class="card-text">
                        Through this website you are able to link to other websites which are not under the control of QwikHom. We have no control over the nature, content and availability of those sites. The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them.
                    </p>
                    <p class="card-text">
                        Every effort is made to keep the website up and running smoothly. However, QwikHom takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
