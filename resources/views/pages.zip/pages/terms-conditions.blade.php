@extends('layouts.app')

@section('title', 'Terms and Conditions | QwikHom')

@section('styles')
<style>
body { background-color: black !important; color: white !important; }
.card { background-color: #333 !important; border-color: #666 !important; }
.card-title, .card-text { color: white !important; }
.card-text li { color: white !important; }
</style>
@endsection

@section('content')
<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <h1 class="mb-4">Terms and Conditions</h1>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Acceptance of Terms</h5>
                    <p class="card-text">
                        By accessing and using QwikHom services, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to these terms, you should not use this service.
                    </p>

                    <h5 class="card-title mt-4">Use License</h5>
                    <p class="card-text">
                        Permission is granted to temporarily access the materials (information or software) on QwikHom's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
                    </p>
                    <ul class="card-text">
                        <li>Modify or copy the materials</li>
                        <li>Use the materials for any commercial purpose or for any public display</li>
                        <li>Attempt to reverse engineer any software contained on the website</li>
                        <li>Remove any copyright or other proprietary notations from the materials</li>
                    </ul>

                    <h5 class="card-title mt-4">Service Description</h5>
                    <p class="card-text">
                        QwikHom provides home service booking platform that connects customers with service providers. We strive to provide accurate and reliable service information, but we cannot guarantee the quality or timeliness of services provided by our partnered service providers.
                    </p>

                    <h5 class="card-title mt-4">User Responsibilities</h5>
                    <p class="card-text">
                        As a user of our platform, you agree to:
                    </p>
                    <ul class="card-text">
                        <li>Provide accurate and complete information when registering</li>
                        <li>Use the service only for lawful purposes</li>
                        <li>Not interfere with the proper functioning of the website</li>
                        <li>Respect the rights of other users and service providers</li>
                    </ul>

                    <h5 class="card-title mt-4">Payment Terms</h5>
                    <p class="card-text">
                        All payments are processed securely through our platform. Service charges may vary based on location, service type, and other factors. Additional fees may apply for certain services or rush orders. Refunds are processed according to our refund policy.
                    </p>

                    <h5 class="card-title mt-4">Limitation of Liability</h5>
                    <p class="card-text">
                        In no event shall QwikHom or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the website or services.
                    </p>

                    <h5 class="card-title mt-4">Contact Information</h5>
                    <p class="card-text">
                        If you have any questions about these Terms and Conditions, please contact us at support@qwikhom.com.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
